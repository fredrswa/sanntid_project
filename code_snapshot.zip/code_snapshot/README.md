Current State of the project

Basic explanation

main:
 - runs each module on a thread with correct channels.
 - waits for timeouts or errors, should implement recovery here.
 
 modules:
 - fsm: from handout
 - network: 
 - IO: coordinating orders. keeps tabs, missing critical logic still
 
 
